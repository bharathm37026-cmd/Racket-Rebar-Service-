# Racket Rebar Service Website

Responsive GitHub Pages website for Racket Rebar Service.

## Files
- `index.html` — website content
- `style.css` — responsive styling
- `script.js` — mobile menu, active navigation and quote form
- `images/` — all local image assets

## GitHub Pages
Upload the contents of this folder to a GitHub repository. In **Settings → Pages**, choose the branch containing `index.html` as the deployment source.
