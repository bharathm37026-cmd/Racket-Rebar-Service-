const menuToggle=document.querySelector('.menu-toggle');
const navLinks=document.querySelector('.nav-links');

menuToggle?.addEventListener('click',()=>{
  const open=navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded',open);
});

document.querySelectorAll('.nav-links a').forEach(link=>{
  link.addEventListener('click',()=>navLinks.classList.remove('open'));
});

const sections=[...document.querySelectorAll('main section[id]')];
const links=[...document.querySelectorAll('.nav-links a[href^="#"]')];
const updateActive=()=>{
  let current='top';
  const y=window.scrollY+120;
  sections.forEach(section=>{if(y>=section.offsetTop) current=section.id});
  links.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+current));
};
window.addEventListener('scroll',updateActive,{passive:true});
updateActive();

document.querySelector('#quoteForm')?.addEventListener('submit',(e)=>{
  e.preventDefault();
  const data=new FormData(e.currentTarget);
  const subject=encodeURIComponent('Rebar Estimate Enquiry - '+(data.get('name')||'Website enquiry'));
  const body=encodeURIComponent(
`Name: ${data.get('name')}
Company: ${data.get('company')}
Email: ${data.get('email')}
Phone: ${data.get('phone')}

Project details:
${data.get('message')}`
  );
  window.location.href=`mailto:info@racketrebarservice.com?subject=${subject}&body=${body}`;
});
